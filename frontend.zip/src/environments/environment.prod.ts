export const environment = {
    production: true,
    apiUrl: 'http://localhost:3000/api',
    version: '1.0.0'
  };
